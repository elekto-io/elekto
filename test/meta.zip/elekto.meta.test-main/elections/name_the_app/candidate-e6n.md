-------------------------------------------------------------
name: e6n
ID: e6n
info:
- Language: Leetspeak
-------------------------------------------------------------

## Reason for Name

"e6n" is the numerical shortening of "e(lectio)n".  It is dorky and very k8s-like.  Nobody will have any idea what it means.

## Availability Search

I didn't even try, really.
