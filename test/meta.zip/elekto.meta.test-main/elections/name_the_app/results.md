# Choose the name of the application election

This election ran from December 29, 2020 and concluded January 5, 2021.  

Four ballots were cast, which is 80% participation.

## Winner: elekto

The new software will be called **elekto**.  A new repository has been created under that name.

The runners-up were:

2nd: delectus

3rd: tie between e6n and Ribemont

5th: NotCIVS
