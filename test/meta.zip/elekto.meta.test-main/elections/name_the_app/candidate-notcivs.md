-------------------------------------------------------------
name: Not CIVS
ID: notcivs
info:
- Language: English
-------------------------------------------------------------

## Reason for Name

This name emphasizes that we are NOT CIVS, for folks who have PTSD from running large elections on CIVS.

## Availability Search

I didn't even try, really.
