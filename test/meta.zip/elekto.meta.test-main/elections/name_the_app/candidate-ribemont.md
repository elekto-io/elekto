-------------------------------------------------------------
name: Ribemont
ID: ribemont
info:
- Language: French
-------------------------------------------------------------

## Reason for Name

The town of Ribemont is the birthplace of the Marquis de Condorcet, the inventor of the Condorcet method.  Other names from the Marquis's life are less available.

## Availability Search

Ribemont is not the name of any international company, and the Github namespace is available.
