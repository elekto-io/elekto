-------------------------------------------------------------
name: delectus
ID: delectus
info:
- Language: Latin
-------------------------------------------------------------

## Reason for Name

"delectus" is one word for "selection" or "election" in Latin.  It is more available than other options.

## Availability Search

Nobody currently seems to have trademarks on the name in the USA.  Various domains are available, as is the Github namespace.
