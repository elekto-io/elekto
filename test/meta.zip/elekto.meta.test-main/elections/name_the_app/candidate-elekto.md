-------------------------------------------------------------
name: elekto
ID: elekto
info:
- Language: Esperanto
-------------------------------------------------------------

## Reason for Name

"elekto" is "election" (or selection, or appointment) in the academic language Esperanto.  Also, it sounds like the name of a C-list superhero.

## Availability Search

Nobody currently seems to have trademarks on the name in the USA.  Various domains are available, as is the Github namespace.
