# Select our GB Rep

This election is for the Steering Committee to select a General Board representative, who will represent us to the CNCF.  All current and former SC members are eligible to run.

As a test, this election will be conducted **both** on Elekto and CIVS.  You should have also received a CIVS ballot in your email.  Please vote using both systems, *exactly the same*, so that we can test that Elekto will work for Kubernetes elections in the future.

Please log any issues you encounter using Elekto by [adding comments to this issue](https://github.com/elekto-io/elekto/issues/3).

Contact Josh Berkus or Bob Killen if you have issues that prevent you from voting.
