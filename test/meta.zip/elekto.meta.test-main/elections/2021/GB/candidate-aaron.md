-------------------------------------------------------------
name: Aaron Crickenberker
ID: aaron
info:
  - employer: Google
-------------------------------------------------------------

Aaron is a former member of the Steering Committee, and one of the founders of SIG-Testing.
