-------------------------------------------------------------
name: Paris Pittman
ID: paris
info:
  - employer: Apple
-------------------------------------------------------------

Paris Pittman is a current member of the SC, and cochair of CNCF SIG-Contributor Strategy
