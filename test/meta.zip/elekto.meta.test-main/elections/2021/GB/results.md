## 2021 General Board Rep for Kubernetes

This election ran from January 11, 2021 to January 13, 2021.

7 ballots were cast, which is 100% participation.

## Winner: Paris Pittman

Paris will be our 2021 GB representative.  Please congratulate her.
