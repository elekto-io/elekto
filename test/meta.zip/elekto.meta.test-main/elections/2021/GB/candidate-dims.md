-------------------------------------------------------------
name: Davanum Srinivas
ID: dims
info:
  - employer: VMware
-------------------------------------------------------------

Davanum Srinivas is a current member of the Steering Committee, and has been a member of the CNCF TOC.
